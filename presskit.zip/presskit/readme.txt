Thanks for downloading the press kit! I really appreciate your interest in my project!

If you have any questions, feel free to contact me in the way you want.

@nikolasklein
fb.com/nikolasklein
vimeo.com/nikolasklein
ello.co/nikolasklein

or via mail

nikolas.klein@icloud.com


Since you are already here — I’m looking for an internship position starting around July 2015. So if you know anything where I can work as an Interaction Designer focused on User Experience, User Interface and these delightful Details… Let me know!


This work and the downloadable content is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License.